using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace SalaAccettazioni
{
    public partial class ModuloAccettazioni : Form
    {
        private int pazientiTotali;
        private int numeroProssimoPaziente;
        private List<PictureBox> filaAttesa = new List<PictureBox>();
        private PictureBox[] sportelli;
        private Label[] etichetteSportelli;
        private Label labelTotP;
        private Random casuale = new Random();
        private Button[] bottoniSportelli;
        private object filaAttesaLock = new object();

        public ModuloAccettazioni()
        {
            InizializzaComponenti();
            InizializzaSportelli();
            InizializzaFilaAttesa();
            AvviaGenerazionePazienti();
        }

        private void InizializzaSportelli()
        {
            sportelli = new PictureBox[3];
            etichetteSportelli = new Label[3];
            bottoniSportelli = new Button[3];

            for (int i = 0; i < sportelli.Length; i++)
            {
                PictureBox sportello = new PictureBox
                {
                    Size = new Size(60, 60),
                    Location = new Point(40 + i * 180, 20),
                    BackColor = Color.LightGray,
                    BorderStyle = BorderStyle.FixedSingle
                };
                Label etichettaSportello = new Label
                {
                    Text = $"Sportello {i + 1}: Nessun paziente",
                    Location = new Point(40 + i * 180, 90),
                    AutoSize = true
                };
                Button bottoneSportello = new Button
                {
                    Text = $"Sportello {i + 1}",
                    Location = new Point(40 + i * 180, 120),
                    Size = new Size(120, 30),
                    Tag = i
                };
                bottoneSportello.Click += BottoneSportello_Click;

                this.Controls.Add(sportello);
                this.Controls.Add(etichettaSportello);
                this.Controls.Add(bottoneSportello);

                sportelli[i] = sportello;
                etichetteSportelli[i] = etichettaSportello;
                bottoniSportelli[i] = bottoneSportello;
            }

            labelTotalePazienti = new Label
            {
                Text = "Pazienti totali: 0",
                Location = new Point(this.ClientSize.Width - 150, 10),
                AutoSize = true
            };
            this.Controls.Add(labelTotalePazienti);
        }

        private void InizializzaFilaAttesa()
        {
            for (int i = 0, j = 0; i < 1000; i++, j++)
            {
                if (j * 50 + 20 >= this.ClientSize.Width)
                    j = 0;

                PictureBox avatarPaziente = new PictureBox
                {
                    Size = new Size(40, 95),
                    Location = new Point(20 + j * 50, 300),
                    BackColor = Color.Transparent,
                    BorderStyle = BorderStyle.FixedSingle,
                    Visible = false
                };

                try
                {
                    avatarPaziente.Image = Image.FromFile(Path.Combine("immagini", "avatar.png"));
                    avatarPaziente.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Errore durante il caricamento dell'immagine: {ex.Message}");
                }

                this.Controls.Add(avatarPaziente);
                filaAttesa.Add(avatarPaziente);
            }

            numeroProssimoPaziente = 1;
        }

        private void AvviaGenerazionePazienti()
        {
            Thread threadGenerazione = new Thread(() =>
            {
                while (true)
                {
                    lock (filaAttesaLock)
                    {
                        if (numeroProssimoPaziente <= filaAttesa.Count)
                        {
                            if (this.IsHandleCreated)
                            {
                                this.Invoke(new Action(() =>
                                {
                                    filaAttesa[numeroProssimoPaziente - 1].Visible = true;
                                    pazientiTotali++;
                                    labelTotalePazienti.Text = $"Pazienti totali: {pazientiTotali}";
                                }));
                            }
                            numeroProssimoPaziente++;
                        }
                    }

                    Thread.Sleep(casuale.Next(1000, 3000));
                }
            });

            threadGenerazione.IsBackground = true;
            threadGenerazione.Start();
        }

        private void BottoneSportello_Click(object sender, EventArgs e)
        {
            Button bottonePremuto = sender as Button;
            int indiceSportello = (int)bottonePremuto.Tag;

            if (pazientiTotali > 0 && sportelli[indiceSportello].BackColor == Color.LightGray)
            {
                int numeroPaziente;

                lock (filaAttesaLock)
                {
                    numeroPaziente = numeroProssimoPaziente - pazientiTotali;

                    if (numeroPaziente <= 0 || numeroPaziente > filaAttesa.Count || !filaAttesa[numeroPaziente - 1].Visible)
                    {
                        MessageBox.Show("Errore: nessun paziente disponibile!");
                        return;
                    }

                    filaAttesa[numeroPaziente - 1].Visible = false;
                    pazientiTotali--;
                }

                this.Invoke(new Action(() =>
                {
                    sportelli[indiceSportello].BackColor = Color.LightGreen;
                    etichetteSportelli[indiceSportello].Text = $"Sportello {indiceSportello + 1}: Paziente {numeroPaziente}";
                    labelTotalePazienti.Text = $"Pazienti totali: {pazientiTotali}";
                }));

                Thread threadServizio = new Thread(() =>
                {
                    Thread.Sleep(5000);

                    this.Invoke(new Action(() =>
                    {
                        sportelli[indiceSportello].BackColor = Color.LightGray;
                        etichetteSportelli[indiceSportello].Text = $"Sportello {indiceSportello + 1}: Nessun paziente";
                    }));
                });

                threadServizio.IsBackground = true;
                threadServizio.Start();
            }
        }

        private void InizializzaComponenti()
        {
            this.SuspendLayout();
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 500);
            this.Name = "ModuloAccettazioni";
            this.Text = "Sala Accettazioni";
            this.ResumeLayout(false);
        }

        private PictureBox sportello1;

        private void InitializeComponent()
        {
            sportello1 = new PictureBox();
            sportello2 = new PictureBox();
            sportello3 = new PictureBox();
            btnsportello1 = new Button();
            btnsportello2 = new Button();
            btnsportello3 = new Button();
            labelTotP = new Label();
            etichettaSportello1 = new Label();
            etichettaSportello2 = new Label();
            etichettaSportello3 = new Label();
            ((System.ComponentModel.ISupportInitialize)sportello1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sportello2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sportello3).BeginInit();
            SuspendLayout();
            // 
            // sportello1
            // 
            sportello1.BackColor = SystemColors.GradientActiveCaption;
            sportello1.Location = new Point(100, 50);
            sportello1.Name = "sportello1";
            sportello1.Size = new Size(125, 125);
            sportello1.TabIndex = 0;
            sportello1.TabStop = false;
            // 
            // sportello2
            // 
            sportello2.BackColor = SystemColors.GradientActiveCaption;
            sportello2.Location = new Point(425, 50);
            sportello2.Name = "sportello2";
            sportello2.Size = new Size(125, 125);
            sportello2.TabIndex = 1;
            sportello2.TabStop = false;
            // 
            // sportello3
            // 
            sportello3.BackColor = SystemColors.GradientActiveCaption;
            sportello3.Location = new Point(750, 50);
            sportello3.Name = "sportello3";
            sportello3.Size = new Size(125, 125);
            sportello3.TabIndex = 2;
            sportello3.TabStop = false;
            // 
            // btnsportello1
            // 
            btnsportello1.BackColor = Color.Gold;
            btnsportello1.Location = new Point(100, 220);
            btnsportello1.Name = "btnsportello1";
            btnsportello1.Size = new Size(125, 61);
            btnsportello1.TabIndex = 3;
            btnsportello1.Text = "SPORTELLO 1";
            btnsportello1.UseVisualStyleBackColor = false;
            // 
            // btnsportello2
            // 
            btnsportello2.BackColor = Color.Gold;
            btnsportello2.Location = new Point(425, 220);
            btnsportello2.Name = "btnsportello2";
            btnsportello2.Size = new Size(125, 61);
            btnsportello2.TabIndex = 4;
            btnsportello2.Text = "SPORTELLO 2";
            btnsportello2.UseVisualStyleBackColor = false;
            // 
            // btnsportello3
            // 
            btnsportello3.BackColor = Color.Gold;
            btnsportello3.Location = new Point(750, 220);
            btnsportello3.Name = "btnsportello3";
            btnsportello3.Size = new Size(125, 61);
            btnsportello3.TabIndex = 5;
            btnsportello3.Text = "SPORTELLO 3";
            btnsportello3.UseVisualStyleBackColor = false;
            // 
            // labelTotP
            // 
            labelTotP.AutoSize = true;
            labelTotP.Location = new Point(450, 9);
            labelTotP.Name = "labelTotP";
            labelTotP.Size = new Size(83, 25);
            labelTotP.TabIndex = 6;
            labelTotP.Text = "labelTotP";
            // 
            // etichettaSportello1
            // 
            etichettaSportello1.AutoSize = true;
            etichettaSportello1.Location = new Point(134, 192);
            etichettaSportello1.Name = "etichettaSportello1";
            etichettaSportello1.Size = new Size(59, 25);
            etichettaSportello1.TabIndex = 7;
            etichettaSportello1.Text = "label1";
            // 
            // etichettaSportello2
            // 
            etichettaSportello2.AutoSize = true;
            etichettaSportello2.Location = new Point(461, 192);
            etichettaSportello2.Name = "etichettaSportello2";
            etichettaSportello2.Size = new Size(59, 25);
            etichettaSportello2.TabIndex = 8;
            etichettaSportello2.Text = "label2";
            // 
            // etichettaSportello3
            // 
            etichettaSportello3.AutoSize = true;
            etichettaSportello3.Location = new Point(783, 192);
            etichettaSportello3.Name = "etichettaSportello3";
            etichettaSportello3.Size = new Size(59, 25);
            etichettaSportello3.TabIndex = 9;
            etichettaSportello3.Text = "label3";
            // 
            // ModuloAccettazioni
            // 
            ClientSize = new Size(967, 644);
            Controls.Add(etichettaSportello3);
            Controls.Add(etichettaSportello2);
            Controls.Add(etichettaSportello1);
            Controls.Add(labelTotP);
            Controls.Add(btnsportello3);
            Controls.Add(btnsportello2);
            Controls.Add(btnsportello1);
            Controls.Add(sportello3);
            Controls.Add(sportello2);
            Controls.Add(sportello1);
            Name = "ModuloAccettazioni";
            ((System.ComponentModel.ISupportInitialize)sportello1).EndInit();
            ((System.ComponentModel.ISupportInitialize)sportello2).EndInit();
            ((System.ComponentModel.ISupportInitialize)sportello3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private PictureBox sportello2;
        private PictureBox sportello3;
        private Button btnsportello1;
        private Button btnsportello2;
        private Button btnsportello3;
        private Label labelTotalePazienti;
        private Label etichettaSportello1;
        private Label etichettaSportello2;
        private Label etichettaSportello3;
    }
}
